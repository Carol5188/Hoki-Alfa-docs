# Browser Harness 可移植包

这个目录是给另一台 Codex 使用的 Browser 技能包，包含：

- `browser-harness/SKILL.md`：当前启用的浏览器操作规范，保持原文
- `browser-harness/install.md`：上游安装、连接 Chrome 和故障排查说明
- `browser-harness/src/browser_harness/`：Browser Harness 核心源码，本地版本 0.1.6
- `browser-harness/interaction-skills/`：上传、标签页、弹窗、截图、iframe 等交互指南
- `browser-harness/agent-workspace/agent_helpers.py`：任务级辅助函数入口
- `browser-harness/pyproject.toml`：运行环境及依赖声明
- `browser-harness/LICENSE`：MIT 许可证

## 给另一个 Codex 的说明

解压后，把以下文字连同解压目录交给另一个 Codex：

> 请先阅读 browser-harness/SKILL.md，再阅读 browser-harness/install.md，理解并按这套 Browser 技能操作。需要实际使用时，请根据目标机器环境安装运行依赖并配置技能目录；参考包内 pyproject.toml，优先复用已有安装。保留交互指南的相对路径。连接用户已打开的 Chrome，先用 page_info() 验证连接。安装说明中的下载最新版、云浏览器和录屏均为可选步骤，请按本次任务需要处理。

安装或浏览器连接说明以包内 `browser-harness/install.md` 为起点；它是本机检出版本的上游文档，并未在另一台电脑上实测。包内依赖需要在目标机器安装，本包不是离线依赖安装包。

## 打包说明

当前启用的技能目录原来只有 `SKILL.md`；本包从本地源码仓库补齐配套指南、源码、测试、许可证和安装说明。Windows 检出中 `src/browser_harness/SKILL.md` 原为文本形式的链接目标 `../../SKILL.md`，打包时替换为当前启用技能的完整正文。

包内的部分上游交互指南较简短，例如 `uploads.md`。这些文件保持本地原样，没有补写不存在的操作方法。

未打包社区可选站点示例 `agent-workspace/domain-skills/`；默认技能已关闭这些示例。未打包虚拟环境、Git 历史、运行状态、浏览器配置、登录数据或历史任务文件。
